(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    ///////////////scroll header////////////////////////
    // $(window).scroll(function() {
    // 	if ($(this).scrollTop() > 1 && $(this).scrollTop() < 2000){
    //    		$('.stick').addClass("sticky");
    //  		}
    // 		 else{
    //   			 $('.stick').removeClass("sticky");
    // 			 }
    // });
    ///////////////scroll header/////////////////////////
    ////////////////mob nav//////////////////////////////
    $('.nav__mob').hide(); //?

    $('.mob').on('click', function () {
      $('.nav__mob').slideToggle();
      $('.mob span').toggleClass('active');
    }); ///////////////mob nav///////////////////////////////
    /////////////////SCROLL////////////////////////////////
    //  $(".nav, .nav_mob").on("click","a", function (event) {
    //   //отменяем стандартную обработку нажатия по ссылке
    //   event.preventDefault();
    //   //забираем идентификатор бока с атрибута href
    //   var id  = $(this).attr('href'),
    //   //узнаем высоту от начала страницы до блока на который ссылается якорь
    //     top = $(id).offset().top;
    //   //анимируем переход на расстояние - top за 1500 мс
    //   $('body,html').animate({scrollTop: top}, 1500);
    // });
    ////////////////END SCROLL////////////////////////////////
    ////////////////ADD CLASS/////////////////////////////////
    // $("#selectBackground ul li a").click(function(e) {
    //   e.preventDefault();
    //   $("#selectBackground ul li a").removeClass('active');
    //   $(this).addClass('active');
    // });
    ///////////////END ADD CLASS//////////////////////////////

    $('.sliderJs').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      dots: true,
      nextArrow: "<button class=\"next\">\n                  <svg viewBox=\"0 0 25 38\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                    <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24.1252 35.5617L2.89577 18.9523L24.1252 2.38127L23.211 1.22769L0.494274 18.9523L23.2258 36.6769L24.1252 35.5617Z\"  stroke-width=\"0.5\"/>\n                  </svg>\n                </button>",
      prevArrow: "<button class=\"prev\">\n                  <svg viewBox=\"0 0 25 38\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                    <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24.1252 35.5617L2.89577 18.9523L24.1252 2.38127L23.211 1.22769L0.494274 18.9523L23.2258 36.6769L24.1252 35.5617Z\"  stroke-width=\"0.5\"/>\n                  </svg>\n                </button>",
      responsive: [{
        breakpoint: 992,
        settings: 'unslick'
      }]
    });
    $('.slider').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      //infinite: false,
      nextArrow: "<button class=\"next\">\n                  <svg viewBox=\"0 0 25 38\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                    <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24.1252 35.5617L2.89577 18.9523L24.1252 2.38127L23.211 1.22769L0.494274 18.9523L23.2258 36.6769L24.1252 35.5617Z\"  stroke-width=\"0.5\"/>\n                  </svg>\n                </button>",
      prevArrow: "<button class=\"prev\">\n                  <svg viewBox=\"0 0 25 38\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                    <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24.1252 35.5617L2.89577 18.9523L24.1252 2.38127L23.211 1.22769L0.494274 18.9523L23.2258 36.6769L24.1252 35.5617Z\"  stroke-width=\"0.5\"/>\n                  </svg>\n                </button>"
    });

    function slickify() {
      $('.catalogSectionJs').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        //infinite: false,
        nextArrow: "<button class=\"next\">\n                    <svg viewBox=\"0 0 25 38\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                      <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24.1252 35.5617L2.89577 18.9523L24.1252 2.38127L23.211 1.22769L0.494274 18.9523L23.2258 36.6769L24.1252 35.5617Z\"  stroke-width=\"0.5\"/>\n                    </svg>\n                  </button>",
        prevArrow: "<button class=\"prev\">\n                    <svg viewBox=\"0 0 25 38\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                      <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24.1252 35.5617L2.89577 18.9523L24.1252 2.38127L23.211 1.22769L0.494274 18.9523L23.2258 36.6769L24.1252 35.5617Z\"  stroke-width=\"0.5\"/>\n                    </svg>\n                  </button>"
      });
    }

    $(window).resize(function () {
      var $windowWidth = $(window).width();

      if ($windowWidth < 600) {
        slickify();
      }
    });

    if ($(window).width() < 600) {
      slickify();
    }

    function slickify2() {
      $('.productWrap__item_un').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        //infinite: false,
        nextArrow: "<button class=\"next\">\n                  <svg viewBox=\"0 0 25 38\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                    <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24.1252 35.5617L2.89577 18.9523L24.1252 2.38127L23.211 1.22769L0.494274 18.9523L23.2258 36.6769L24.1252 35.5617Z\"  stroke-width=\"0.5\"/>\n                  </svg>\n                </button>",
        prevArrow: "<button class=\"prev\">\n                  <svg viewBox=\"0 0 25 38\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                    <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M24.1252 35.5617L2.89577 18.9523L24.1252 2.38127L23.211 1.22769L0.494274 18.9523L23.2258 36.6769L24.1252 35.5617Z\"  stroke-width=\"0.5\"/>\n                  </svg>\n                </button>"
      });
    }

    $(window).resize(function () {
      var $windowWidth = $(window).width();

      if ($windowWidth < 600) {
        slickify2();
      }
    });

    if ($(window).width() < 600) {
      slickify2();
    }

    $('.fotos').slick({
      slidesToShow: 6,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 2000,
      arrows: false,
      responsive: [{
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          centerMode: true,
          centerPadding: '80px'
        }
      }]
    });
    $('.select').each(function () {
      var _this = $(this),
          selectOption = _this.find('option'),
          selectOptionLength = selectOption.length;

      selectOption.filter(':selected');
      var duration = 450; // длительность анимации

      _this.hide();

      _this.wrap('<div class="select"></div>');

      $('<div>', {
        "class": 'new-select',
        text: _this.children('option:disabled').text()
      }).insertAfter(_this);

      var selectHead = _this.next('.new-select');

      $('<div>', {
        "class": 'new-select__list'
      }).insertAfter(selectHead);
      var selectList = selectHead.next('.new-select__list');

      for (var i = 1; i < selectOptionLength; i++) {
        $('<div>', {
          "class": 'new-select__item',
          html: $('<span>', {
            text: selectOption.eq(i).text()
          })
        }).attr('data-value', selectOption.eq(i).val()).appendTo(selectList);
      }

      var selectItem = selectList.find('.new-select__item');
      selectList.slideUp(0);
      selectHead.on('click', function () {
        if (!$(this).hasClass('on')) {
          $(this).addClass('on');
          selectList.slideDown(duration);
          selectItem.on('click', function () {
            var chooseItem = $(this).data('value');
            $('select').val(chooseItem).attr('selected', 'selected');
            $(_this.wrap()).trigger("change");
            selectHead.text($(this).find('span').text());
            selectList.slideUp(duration);
            selectHead.removeClass('on');
          });
        } else {
          $(this).removeClass('on');
          selectList.slideUp(duration);
        }
      });
    });
    $('.btnCart').on('click', function () {
      $('.cart').slideToggle();
      $(this).toggleClass('active');
    });
    $('.close').on('click', function () {
      $('.cart').slideToggle();
      $('.btnCart').toggleClass('active');
    }); ////////////////////////////////////////////////

    $('.cartItemAdd__btn').on('click', function () {
      $('.cartItemAdd').toggleClass('active');
    });
    $('.cartItemAdd__body_close').on('click', function () {
      $('.cartItemAdd').toggleClass('active');
    }); //////////////////////////////////////////////////

    $('.product__sizeBtn').on('click', function () {
      $('.overlay').toggleClass('active');
    });
    $('.closePopup').on('click', function () {
      $('.overlay').toggleClass('active');
    });
  }); // end DOMContentLoaded
})();
//# sourceMappingURL=theme.js.map
